# Пример цикла for
for i in range(5):
    print("Итерация:", i)