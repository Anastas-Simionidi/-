# цикл while
count = 0
while count < 5:
    print("Счетчик:",count)
    count += 1
    # увеличивет счечткик на 1